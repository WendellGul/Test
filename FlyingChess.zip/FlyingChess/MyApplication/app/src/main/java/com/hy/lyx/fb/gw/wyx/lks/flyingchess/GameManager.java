package com.hy.lyx.fb.gw.wyx.lks.flyingchess;

import android.os.Bundle;
import android.os.Message;

import java.util.LinkedList;
import java.util.Random;

/**
 * Created by karthur on 2016/4/9.
 */
public class GameManager implements Target {//game process control
    private GameWorker gw;//thread
    private ChessBoardAct board;
    private boolean waitForDice,waitForPlane,finished;
    private int dice,whichPlane;
    public GameManager(){
        gw=new GameWorker();
        Game.socketManager.registerActivity(DataPack.E_GAME_PROCEED_PLANE,this);
        Game.socketManager.registerActivity(DataPack.E_GAME_PROCEED_DICE,this);
        Game.socketManager.registerActivity(DataPack.E_GAME_FINISHED, this);
    }

    public void newTurn(ChessBoardAct board){//call by activity when game start
        Game.chessBoard.init();
        this.board=board;
        finished=false;
        new Thread(gw).start();
    }

    public void gameOver(){
        gw.exit();
    }

    public void turnTo(int color){//call by other thread  be careful
        if(color==Game.playerMapData.get("me").color){//it is my turn
            //get dice
            dice=Player.roll();


            LinkedList<String> msgs=new LinkedList<>();
            msgs.addLast(Game.playerMapData.get("me").id);
            msgs.addLast(Game.dataManager.getRoomId());
            msgs.addLast(String.format("%d",dice));
            Game.socketManager.send(new DataPack(DataPack.E_GAME_PROCEED_DICE,msgs));
            //UI update
            diceAnimate(dice);



            if(Player.canIMove(color,dice)){//can move a plane
                //get plane
                do {
                    whichPlane=Player.choosePlane();
                }while(!Player.move(color,whichPlane,dice));
                ///UI update
                flyNow(color);
            }
            else{
                toast("i can not move");
            }

            //tell other players
            LinkedList<String> msgs1=new LinkedList<>();
            msgs1.addLast(Game.playerMapData.get("me").id);
            msgs1.addLast(Game.dataManager.getRoomId());
            msgs1.addLast(String.format("%d",whichPlane));
            Game.socketManager.send(new DataPack(DataPack.E_GAME_PROCEED_PLANE,msgs));

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        else{//others
            switch (Game.dataManager.getGameMode()){
                case DataManager.GM_LOCAL://local game
                {
                    Random r=new Random(System.currentTimeMillis());
                    dice=r.nextInt(6)+1;
                    //UI
                    diceAnimate(dice);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    if(Player.canIMove(color,dice)){
                        do{
                            whichPlane=r.nextInt(4);
                        }while(!Player.move(color,whichPlane,dice));
                        ///UI update
                        flyNow(color);
                        //
                    }

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                    break;
                case DataManager.GM_LAN:
                    break;
                case DataManager.GM_WLAN:
                {
                    waitForPlane=true;
                    waitForDice=true;
                    while(waitForDice){
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    ///////whichplane  dice;
                    diceAnimate(dice);
                    while(waitForPlane) {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    if(Player.canIMove(color,dice)) {
                        Player.move(color, whichPlane, dice);
                        flyNow(color);
                    }
                    /////////is finished?
                    if(finished){

                    }
                }
                    break;
            }
        }

    }

    private void diceAnimate(int dice){
        for(int i=0;i<15;i++){
            Message msg = new Message();
            Bundle b = new Bundle();
            b.putString("dice",String.format("%d",Game.chessBoard.getDice().roll()));
            msg.setData(b);
            msg.what=2;
            board.handler.sendMessage(msg);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Message msg = new Message();
        Bundle b = new Bundle();
        b.putString("dice",String.format("%d",dice));
        msg.setData(b);
        msg.what=2;
        board.handler.sendMessage(msg);
    }

    private void planeAnimate(int color, int pos){
        Message msg2 = new Message();
        Bundle b2 = new Bundle();
        b2.putInt("color",color);
        b2.putInt("whichPlane",whichPlane);
        b2.putInt("pos", pos);
        msg2.setData(b2);
        msg2.what = 1;
        board.handler.sendMessage(msg2);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void planeCrack(int color, int crackPlane) {
        Message msg = new Message();
        Bundle b = new Bundle();
        b.putInt("color", color);
        b.putInt("whichPlane", crackPlane);
        b.putInt("pos", Game.chessBoard.getAirplane(color).position[crackPlane]);
        msg.setData(b);
        msg.what = 4;
        board.handler.sendMessage(msg);
    }

    private void flyNow(int color) {
        int toPos = Game.chessBoard.getAirplane(color).position[whichPlane];
        int curPos = Game.chessBoard.getAirplane(color).curPos[whichPlane];
        if(curPos + dice == toPos || curPos == -1) {
            for (int pos = curPos + 1; pos <= toPos; pos++) {
                planeAnimate(color, pos);
            }
            crack(color, toPos);
        }
        else if(curPos + dice + 4 == toPos) { // short jump
            for(int pos = curPos + 1; pos <= curPos + dice; pos++) {
                planeAnimate(color, pos);
            }
            crack(color, curPos + dice);
            planeAnimate(color, toPos);
            crack(color, curPos);
        }
        else if(toPos == 30) { // short jump and then long jump
            for(int pos = curPos + 1; pos <= curPos + dice; pos++) {
                planeAnimate(color, pos);
            }
            crack(color, curPos + dice);
            planeAnimate(color, 18);
            crack(color, 18);
            planeAnimate(color, 30);
            crack(color, 30);
        }
        else if(toPos == 34) { // long jump and then short jump
            for(int pos =curPos + 1; pos <= 18; pos++) {
                planeAnimate(color, pos);
            }
            crack(color, 18);
            planeAnimate(color, 30);
            crack(color, 30);
            planeAnimate(color, 34);
            crack(color, 34);
        }
        else if(Game.chessBoard.isOverflow()) { // overflow
            for (int pos = curPos + 1; pos <= 56; pos++) {
                planeAnimate(color, pos);
            }
            for(int pos = 55; pos >= toPos; pos--)
                planeAnimate(color, pos);
            crack(color, toPos);
            Game.chessBoard.setOverflow(false);
        }
    }

    public void crack(int color, int pos) {
        int crackColor = color;
        int crackPlane = whichPlane;
        int count = 0;
        for(int i = 0; i < 4; i++) {
            if(i != color) {
                for(int j = 0; j < 4; j++) {
                    int crackPos = Game.chessBoard.getAirplane(i).position[j];
                    int factor = (i - color + 4) % 4;
                    if(pos != 0 && crackPos != 0 && crackPos == (pos + 13 * factor) % 52) {
                        crackPlane = j;
                        count++;
                    }
                }
                if(count == 1)
                    crackColor = i;
                if(count >= 1)
                    break;
            }
        }
        if(count >= 1) {
            planeCrack(crackColor, crackPlane);
            Game.chessBoard.getAirplane(crackColor).position[crackPlane] = -1;
            Game.chessBoard.getAirplane(crackColor).curPos[crackPlane] = -1;
        }
    }


    private void toast(String msgs){
        Message msg = new Message();
        Bundle b = new Bundle();
        b.putString("msg",msgs);
        msg.setData(b);
        msg.what=3;
        board.handler.sendMessage(msg);
    }

    @Override
    public void processDataPack(DataPack dataPack) {
        switch (dataPack.getCommand()){
            case DataPack.E_GAME_FINISHED:
                finished=true;
                break;
            case DataPack.E_GAME_PROCEED_DICE:
                dice=Integer.valueOf(dataPack.getMessage(2));
                waitForDice=false;
                break;
            case DataPack.E_GAME_PROCEED_PLANE:
                whichPlane=Integer.valueOf(dataPack.getMessage(2));
                waitForPlane=false;
                break;
        }
    }
}

class GameWorker implements Runnable{
    private boolean run;

    public GameWorker(){
        run=true;
    }

    @Override
    public void run() {
        int i=0;
        while(run){//control round
            i=(i%4);
            for(String key:Game.playerMapData.keySet()){
                if(Game.playerMapData.get(key).color==i){
                    Game.gameManager.turnTo(i);
                    break;
                }
            }
            i++;
        }
    }

    public void exit(){
        run=false;
    }
}