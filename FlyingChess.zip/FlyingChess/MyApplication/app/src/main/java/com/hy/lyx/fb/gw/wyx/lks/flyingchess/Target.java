package com.hy.lyx.fb.gw.wyx.lks.flyingchess;

public interface Target{
    public void processDataPack(DataPack dataPack);
}
