#**Flying Chess**
##An android game

***
###**Procedure**
Boot -> Choose Mode -> Display Game Information -> Play


***
###**Activity**
* WelcomeAct
* ChooseModeAct
* LoginAct
* GameInfoAct
* ChessBoardAct
* SettingAct


***
###**Java Class**(Besides Activity)
* DataManager
* GameManager
* ChessBoard
